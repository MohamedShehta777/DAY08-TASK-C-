﻿using System;
using System.Collections.Generic;

// IVehicle Interface and Implementations
public interface IVehicle
{
    void StartEngine();
    void StopEngine();
}

public class Car : IVehicle
{
    public void StartEngine() => Console.WriteLine("Car engine started.");
    public void StopEngine() => Console.WriteLine("Car engine stopped.");
}

public class Bike : IVehicle
{
    public void StartEngine() => Console.WriteLine("Bike engine started.");
    public void StopEngine() => Console.WriteLine("Bike engine stopped.");
}

//Coding against an interface improves flexibility and reusability by decoupling code from specific implementations. 
//This enables polymorphism, easier testing (mocking), and allows new implementations to be added without modifying existing code.
//--------------------------------------------------------------//


// Shape Abstract Class and Implementations
public abstract class Shape
{
    public abstract double GetArea();
    public void Display() => Console.WriteLine($"The area is: {GetArea()}");
}

public class Rectangle : Shape
{
    public double Width { get; set; }
    public double Height { get; set; }

    public Rectangle(double width, double height)
    {
        Width = width;
        Height = height;
    }

    public override double GetArea() => Width * Height;
}

public class Circle : Shape
{
    public double Radius { get; set; }
    public Circle(double radius) => Radius = radius;
    public override double GetArea() => Math.PI * Radius * Radius;
}
//abstract when:
//There’s a need to share common functionality (e.g., Display()).
//A "base type" relationship exists, and inheritance makes sense.
//interface when:
//No shared implementation is required.
//Multiple inheritance of behavior is needed.
//--------------------------------------------//




// Product Class with IComparable Implementation
public class Product : IComparable<Product>
{
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }

    public Product(int id, string name, decimal price)
    {
        Id = id;
        Name = name;
        Price = price;
    }

    public int CompareTo(Product other) => Price.CompareTo(other.Price);
    public override string ToString() => $"{Name}: {Price:C}";
}
//It allows objects to be sorted using different criteria, without modifying external code or requiring separate comparator functions.
//--------------------------------------//

// Student Class with Copy Constructor
public class Student
{
    public int Id { get; set; }
    public string Name { get; set; }
    public int Grade { get; set; }

    public Student(int id, string name, int grade)
    {
        Id = id;
        Name = name;
        Grade = grade;
    }

    public Student(Student original)
    {
        Id = original.Id;
        Name = string.Copy(original.Name);
        Grade = original.Grade;
    }

    public override string ToString() => $"{Name} (Id: {Id}, Grade: {Grade})";
}
//To create a deep copy of an object, ensuring changes to the copied object do not affect the original.
//--------------------------------------------------//

// IWalkable Interface and Robot Implementation
public interface IWalkable
{
    void Walk();
}

public class Robot : IWalkable
{
    public void Walk()
    {
        Console.WriteLine("Robot is walking using its default behavior.");
    }

    void IWalkable.Walk()
    {
        Console.WriteLine("Robot is walking as defined by the IWalkable interface.");
    }
}
//Explicit interface implementation allows a class to provide distinct behaviors for its own methods 
//and interface methods, avoiding naming conflicts and enabling clearer separation of responsibilities.
//---------------------------------------------------//

// Account Struct
public struct Account
{
    private int accountId;
    private string accountHolder;
    private decimal balance;

    public int AccountId
    {
        get => accountId;
        set => accountId = value;
    }

    public string AccountHolder
    {
        get => accountHolder;
        set => accountHolder = value;
    }

    public decimal Balance
    {
        get => balance;
        set => balance = value;
    }

    public override string ToString() => $"Account ID: {AccountId}, Holder: {AccountHolder}, Balance: {Balance:C}";
}

//1-:
//Structs are value types and do not support inheritance. Encapsulation in structs is similar to classes, but structs are better suited for lightweight objects.
//2-:
//Abstraction hides implementation details and exposes only the necessary features, focusing on "what" an object does rather than "how." Encapsulation supports abstraction 
//by bundling data and behavior and controlling access via access modifiers.
//------------------------------------------------------//

// ILogger Interface with Default Implementation
public interface ILogger
{
    void Log()
    {
        Console.WriteLine("Default log implementation.");
    }
}

public class ConsoleLogger : ILogger
{
    public void Log()
    {
        Console.WriteLine("Logging to the console.");
    }
}

//Default interface implementations allow new methods to be added to interfaces without breaking existing implementations, ensuring smoother evolution of APIs.
//----------------------------------------------------//

// Book Class with Constructor Overloading
public class Book
{
    public string Title { get; set; }
    public string Author { get; set; }

    public Book()
    {
        Title = "Untitled";
        Author = "Unknown";
    }

    public Book(string title)
    {
        Title = title;
        Author = "Unknown";
    }

    public Book(string title, string author)
    {
        Title = title;
        Author = author;
    }

    public override string ToString() => $"Title: {Title}, Author: {Author}";
}

//Constructor overloading provides flexibility by allowing objects to be initialized in multiple ways, reducing the need for repetitive code and improving clarity.
//----------------------------------------------------------------------//

// Main Program
class Program
{
    static void Main()
    {
        Console.WriteLine("=== IVehicle Interface ===");
        IVehicle car = new Car();
        IVehicle bike = new Bike();
        car.StartEngine();
        car.StopEngine();
        bike.StartEngine();
        bike.StopEngine();

        Console.WriteLine("\n=== Shape Abstract Class ===");
        Shape rectangle = new Rectangle(5, 10);
        rectangle.Display();
        Shape circle = new Circle(7);
        circle.Display();

        Console.WriteLine("\n=== Product Sorting ===");
        List<Product> products = new List<Product>
        {
            new Product(1, "Laptop", 1200m),
            new Product(2, "Phone", 800m),
            new Product(3, "Tablet", 500m)
        };
        products.Sort();
        foreach (var product in products) Console.WriteLine(product);

        Console.WriteLine("\n=== Student Copy Constructor ===");
        Student original = new Student(1, "Alice", 90);
        Student copy = new Student(original);
        copy.Name = "Bob";
        Console.WriteLine(original);
        Console.WriteLine(copy);

        Console.WriteLine("\n=== IWalkable Interface ===");
        Robot robot = new Robot();
        robot.Walk();
        IWalkable walkableRobot = robot;
        walkableRobot.Walk();

        Console.WriteLine("\n=== Account Struct ===");
        Account account = new Account
        {
            AccountId = 101,
            AccountHolder = "John Doe",
            Balance = 1000.50m
        };
        Console.WriteLine(account);

        Console.WriteLine("\n=== ILogger Interface ===");
        ILogger logger = new ConsoleLogger();
        logger.Log();

        Console.WriteLine("\n=== Book Constructor Overloading ===");
        Book book1 = new Book();
        Book book2 = new Book("1984");
        Book book3 = new Book("To Kill a Mockingbird", "Harper Lee");
        Console.WriteLine(book1);
        Console.WriteLine(book2);
        Console.WriteLine(book3);
    }
}

